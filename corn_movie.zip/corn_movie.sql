-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: corn_movie
-- ------------------------------------------------------
-- Server version	5.7.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_cinema`
--

DROP TABLE IF EXISTS `tbl_cinema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_cinema` (
  `cinema_num` int(10) NOT NULL,
  `local_info_city` varchar(50) NOT NULL,
  `local_info_dist` varchar(50) NOT NULL,
  `total_seat` int(10) DEFAULT NULL,
  PRIMARY KEY (`cinema_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cinema`
--

LOCK TABLES `tbl_cinema` WRITE;
/*!40000 ALTER TABLE `tbl_cinema` DISABLE KEYS */;
INSERT INTO `tbl_cinema` VALUES (1,'서울','강남',54),(2,'서울','강동',45),(3,'경기','수원',28),(4,'경기','용인',28);
/*!40000 ALTER TABLE `tbl_cinema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_comments`
--

DROP TABLE IF EXISTS `tbl_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_comments` (
  `id` varchar(50) NOT NULL,
  `movie_num` int(50) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `score` int(1) DEFAULT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`movie_num`),
  KEY `movie_num` (`movie_num`),
  CONSTRAINT `tbl_comments_ibfk_1` FOREIGN KEY (`movie_num`) REFERENCES `tbl_movie` (`movie_num`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_comments`
--

LOCK TABLES `tbl_comments` WRITE;
/*!40000 ALTER TABLE `tbl_comments` DISABLE KEYS */;
INSERT INTO `tbl_comments` VALUES ('asd123',20,'재미있어요 ~ ',5,'2019-11-12 08:07:58','2019-11-12 08:07:58');
/*!40000 ALTER TABLE `tbl_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_member`
--

DROP TABLE IF EXISTS `tbl_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_member` (
  `id` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedate` timestamp NULL DEFAULT NULL,
  `connection_time` timestamp NULL DEFAULT NULL,
  `disconnected_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_member`
--

LOCK TABLES `tbl_member` WRITE;
/*!40000 ALTER TABLE `tbl_member` DISABLE KEYS */;
INSERT INTO `tbl_member` VALUES ('asd123','049a68c15c0d6e26c8b4a0743e6b87f074864c2fae5983c88956cb2882d608f5','김승훈','rlatmdgns94@naver.com','2019-11-12 08:07:19',NULL,'2019-11-12 08:07:29',NULL);
/*!40000 ALTER TABLE `tbl_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_movie`
--

DROP TABLE IF EXISTS `tbl_movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_movie` (
  `movie_num` int(50) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `story` varchar(2000) NOT NULL,
  `actor` varchar(100) NOT NULL,
  `director` varchar(50) NOT NULL,
  `opening_day` varchar(50) NOT NULL,
  `closing_day` varchar(50) NOT NULL,
  `film_rate` varchar(50) NOT NULL,
  `running_time` varchar(30) NOT NULL,
  `avg_score` float NOT NULL,
  `movie_genre` varchar(100) DEFAULT NULL,
  `registration_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modification_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`movie_num`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_movie`
--

LOCK TABLES `tbl_movie` WRITE;
/*!40000 ALTER TABLE `tbl_movie` DISABLE KEYS */;
INSERT INTO `tbl_movie` VALUES (1,'그것:두번째 이야기','‘그것’과 함께 ‘그들’도 돌아왔다! 27년마다 아이들이 사라지는 마을 데리, 또 다시 ‘그것’이 나타났다. 27년 전, 가장 무서워하는 것의 모습으로 나타나 아이들을 잡아먹는 그것 페니와이즈에 맞섰던 ‘루저 클럽’ 친구들은 어른이 되어도 더 커져만 가는 그것의 공포를 끝내기 위해 피할 수 없는 마지막 대결에 나선다.','제시카 차스테인, 제임스 맥어보이, 빌스카스가드, 빌 헤이터','안드레스 무시에티','2019-09-04','2020-09-04','15세 이상 관람가','169분',0,'공포, 스릴러','2019-11-12 07:50:05',NULL),(2,'타짜: 원 아이드 잭','전설적인 타짜 ‘짝귀’의 아들이자 고시생인 ‘일출’(박정민)은 공부에는 흥미가 없지만\n 포커판에서는 날고 기는 실력자다. 포커판에서 우연히 알게 된 ‘마돈나’(최유화)의 묘한 매력에 빠져든 일출은\n 그녀의 곁을 지키는 ‘이상무’(윤제문)에게 속아 포커의 쓴맛을 제대로 배운다.\n 돈도 잃고 자존심까지 무너진 채 벼랑 끝에 몰린 도일출, 그의 앞에 정체불명의 타짜 ‘애꾸’(류승범)가 나타난다.\n \n 거액이 걸린 거대한 판을 설계한 애꾸는 전국에서 타짜들을 불러모은다.\n 일출을 시작으로 셔플의 제왕 까치(이광수), 남다른 연기력의 영미(임지연), 숨은 고수 권원장(권해효)까지\n 무엇이든 될 수 있고, 누구든 이길 수 있는 ‘원 아이드 잭’ 팀으로 모인 이들, 인생을 바꿀 새로운 판에 뛰어드는데…\n \n베팅을 할 때는 인생을 걸어야지! 타짜니까!','박정민, 류승범, 최유나','권오광','2019-09-11','2020-09-04','청소년관람불가','139분',0,'액션, 코메디,','2019-11-12 07:50:05',NULL),(3,'장사리 : 잊혀진 영웅들','인천상륙작전 D-1\n ‘이명준’ 대위가 이끄는 유격대와 전투 경험이 없는 학도병들을 태운 문산호는\n 인천상륙작전의 양동작전인 장사상륙작전을 위해 장사리로 향한다.\n 평균나이 17세, 훈련기간 단 2주에 불과했던 772명 학도병들이\n 악천후 속에서 소나기처럼 쏟아지는 총알을 맞으며 상륙을 시도하는데…','김명민, 최민호, 김성철 ','곽경택, 김태훈','2019-09-25','2020-09-04','12세 이상 관람가','104분',0,'드라마','2019-11-12 07:50:05',NULL),(4,'양자물리학','‘생각이 현실을 만든다’라는 양자물리학적 신념을 인생의 모토로 삼은 유흥계의 화타 ‘이찬우’\n\n어느 날 유명 연예인이 연루된 마약 파티 사건을 눈치챈다.\n“불법 없이! 탈세 없이!” 이 바닥에서도 혁신이 일어나야 한다고 믿는 그는\n오랫동안 알고지낸 범죄정보과 계장 ‘박기헌’에게 이 정보를 흘린다.\n\n단순한 사건이라고 생각했던 마약파티가 연예계는 물론 검찰, 정치계까지 연루된\n거대한 마약 스캔들임을 알게 된 \'이찬우\'.\n이제는 살기 위해 거대 권력과 맞서야 하는 상황.\n\n\'이찬우’는 ‘박기헌’ 계장을 비롯해 황금인맥을 자랑하는 업계 퀸 ‘성은영’ 등 업계 에이스들과 함께 이 사건을 파헤치기로 한다.\n\n9월, 부패 권력에 통쾌하게 맞서라! 생각은 현실을 만드니까!','박해수, 서예지, 김상호','이성태','2019-09-25','2020-09-04','15세 이상 관람가','120분',0,'드라마','2019-11-12 07:50:05',NULL),(5,'조커','“내 인생이 비극인줄 알았는데, 코미디였어”\n고담시의 광대 아서 플렉은 코미디언을 꿈꾸는 남자.\n하지만 모두가 미쳐가는 코미디 같은 세상에서\n맨 정신으로는 그가 설 자리가 없음을 깨닫게 되는데…\n이제껏 본 적 없는 진짜 ‘조커’를 만나라!','호아킨 피닉스, 재지 비츠, 로버트 드니로','토드 필립스','2019-10-02','2020-09-04','15세 이상 관람가','123분',0,'드라마','2019-11-12 07:50:05',NULL),(6,'원스 어폰 어 타임... 인 할리우드','1969년 세계를 떠들썩하게 했던 ‘배우 샤론 테이트 살인 사건’을 기발하게 뒤집은\n타란티노 감독의 마스터피스!\n\n1969년 할리우드, 잊혀져 가는 액션스타 ‘릭 달튼’과 그의 스턴트 배우 겸 매니저인 ‘클리프 부스’는\n과거의 영광을 되찾기 위해 고군분투하지만 새로운 스타들에 밀려 큰 성과를 거두진 못한다.\n\n그러던 어느 날 ‘릭’의 옆집에 할리우드에서\n가장 핫한 ‘로만 폴란스키’ 감독과 배우 ‘샤론 테이트’ 부부가 이사 오자\n‘릭’은 새로운 기회가 생길 수도 있다고 기뻐하지만 인사조차 나누지 못한다.\n\n형편상 더 이상 함께 일할 수 없게 된 ‘릭’과 ‘클리프’는 각자의 길을 가기로 하고\n‘릭’의 집에서 술을 거나하게 마시던 중 뜻하지 않은 낯선 방문객을 맞이하게 되는데…','레오나르도 디카프리오, 브래드 피트, 마고 로비','쿠엔틴 타란티노','2019-09-25','2020-09-04','청소년관람불가','161분',0,'드라마','2019-11-12 07:50:05',NULL),(7,'가장 보통의 연애','전 여친에 상처받은 ‘재훈’(김래원).\n 여느 때처럼 숙취로 시작한 아침,\n 모르는 번호의 누군가와 밤새 2시간이나 통화한 기록을 발견하게 되고\n 그 상대가 바로! 통성명한 지 24시간도 채 되지 않은 직장 동료 ‘선영’임을 알게 된다.\n \n 남친과 뒤끝 있는 이별 중인 ‘선영’(공효진).\n 새로운 회사로 출근한 첫날, 할 말 못 할 말 쏟아내며 남친과 헤어지던 현장에서\n 하필이면! 같은 직장의 ‘재훈’을 마주친다.\n \n 만난 지 하루 만에 일보다 서로의 연애사를 더 잘 알게 된 두 사람.\n 하지만 미묘한 긴장과 어색함도 잠시\n ‘한심하다’, ‘어이없다’ 부딪히면서도 마음이 쓰이는 건 왜 그럴까?','김래원, 공효진','김한결','2019.10.02','2020-09-04','15세 이상 관람가','120분',0,'멜로,애정,로맨스','2019-11-12 07:50:05',NULL),(8,'제미니 맨','최강의 요원 헨리(윌 스미스)는 자신과 완벽하게 닮은 의문의 요원(윌 스미스)에게 맹렬한 추격을 당한다.\n한편 헨리와 이제 막 동료가 된 대니(메리 엘리자베스 윈스티드), 헨리의 오랜 동료 배런(베네딕트 웡)은 의문의 요원에게\n이상한 낌새를 느끼고 정체를 파헤치기 시작하고, 그가 헨리의 DNA를 추출해 탄생한 ‘제미니 프로젝트’ 요원임을 알게 된다.\n헨리의 전성기와 너무나 완벽하게 닮은 한 사람을 만나 충격에 빠지는 헨리와 동료들. 그들은 ‘제미니 프로젝트’를 파괴하기 위한 작전을 시작하는데…','윌 스미스, 메리 엘리자베스 윈스테드, 클라이브 오웬','이안','2019.10.09','2012.10.09','12세 이상 관람가','117분',0,'액션,모험,SF','2019-11-12 07:50:46',NULL),(9,'퍼펙트 맨','퍼펙트한 인생을 위해 한탕을 꿈꾸는 건달 ‘영기’(조진웅)\n조직 보스의 돈 7억을 빼돌려 주식에 투자하지만, 사기꾼에게 속아 주식은 휴지조각이 되고 만다.\n목숨을 부지하기 위해 어떻게든 7억을 구해야 하는 영기 앞에\n까칠한 로펌 대표 ‘장수’(설경구)가 나타난다.\n\n두 달 시한부 ‘장수’는 자신이 해야 할 일들을 도와주는 조건으로\n영기에게 자신의 사망보험금을 내건 빅딜을 제안하는데…','설경구, 조진웅, 허준호','용수','2019.10.02','2020-09-04','15세 이상 관람가','116분',0,'코미디','2019-11-12 07:50:46',NULL),(10,'운명의 힘','사랑에 빠진 후작의 딸 레오노라와 애인 알바로는 달아나던 중 알바로의 실수로 후작을 죽인다. \n이 사건으로 두 사람은 헤어지고, 레오노라는 수도원에 들어가고 알바로는 군대에 자원한다. \n오빠 돈 카를로도 이름을 바꾸고 스페인 군대에 들어가는데 그곳에서 전투 중 알바로와 친구가 된다. \n그러나 알바로가 가지고 있던 레오노라의 초상화를 발견하고는 그의 정체에 분노한다. \n돈 카를로는 복수를 위해 다시 그들을 찾아 헤맨 끝에 알바로를 발견하고 레오노라가 있는 수도원 근처에서 결투를 하게 된다. \n결투 중 칼에 찔린 돈 카를로는 비명 소리를 듣고 달려오던 레오노라를 찌르고 함께 죽는다. 남겨진 알바로는 자신의 운명을 저주한다.','안나 네트렙코, 요나스 카우프만, 뤼도빅 테지에','크리스토프 로이','2019.10.02','2020-09-04','12세 이상 관람가','202분',0,'드라마','2019-11-12 07:50:46',NULL),(11,'잃어버린 세계를 찾아서','예티, 빅풋, 사스콰치라 불리는 전설 속 몬스터\n유일하게 살아남은 ‘Mr. 링크’는 지구 반 바퀴 너머\n잃어버린 세계라 불리는 ‘샹그릴라’에서 동족의 흔적이 발견됐다는 사실을 알게 된다\n\n한편, 자칭 세계 최고의 탐험가라 주장하는 ‘라이오넬’\n‘빅풋’을 목격했다는 편지 한 통을 받고 북아메리카로 향한다\n그리고 ‘라이오넬’의 눈 앞에 나타난 ‘Mr. 링크’!\n\n오랜 시간 숨어 살아온 몬스터 ‘링크’에게는\n가족을 찾기 위해 탐험가 ‘라이오넬’의 도움이 절실한 상황!\n우여곡절 끝에 둘은 함께 모험을 떠나게 되는데…','조 샐다나, 자흐 갈리피아나 키스, 엠마 톰슨, 티모시 올리펀트','크리스 버틀러','2019.10.09','2020-09-04','전체 관람가','95분',0,'모험, 가족, 판타지','2019-11-12 07:50:46',NULL),(12,'소피와 드래곤: 마법책의 비밀','평화로운 왕국의 말괄량이 공주 ‘소피’\n언제나 명랑해 보이지만 어릴 적 잃어버린 엄마를 매일 그리워하는,\n외로운 소녀이기도 하다.\n\n일곱 살 생일을 맞이한 어느 날 ‘소피’는\n호시탐탐 왕의 자리를 노리는 ‘발타샤’의 눈을 피해\n궁전 안에서 놀거리를 찾던 중\n신비한 마법의 책을 발견한다!\n\n호기심에 가득 찬 ‘소피’가\n마법의 책을 펼치자 풍덩! 책 속으로 빠져 들어가게 되고,\n신기한 동물과 아름다운 식물로 가득한 환상의 세계로 건너가\n꼬마 드래곤 ‘드랙스’를 만나게 된다!\n\n매일 밤 마법의 책 속으로 들어가 드래곤 ‘드랙스’와 뛰놀던 ‘소피’는\n원하는 모든 것을 보여 준다는 마법 거울의 비밀을 알게 되는데…','정유정, 김명준, 현경수','마리나 네페도바','2019.10.02','2020-09-04','전체 관람가','72분',0,'애니메이션, 판타지','2019-11-12 07:50:47',NULL),(13,'너를 만난 여름','열일곱, 모든 게 서툴고 어설프지만 모든 게 좋았던 시간.\n너 ♡ 나 = 최고의 우리\n내가 가장 좋아하는 계절은\n\n‘너를 만난 여름’','진비우, 하림두','장적사','2019.10.17','2020-09-04','12세 이상 관람가','109분',0,'멜로,애정,로맨스','2019-11-12 07:50:47',NULL),(14,'신문기자','“나는 진실을 알려야 하는 기자예요”\n\n일본 열도를 발칵 뒤집을 충격적인 익명의 제보\n고위 관료의 석연치 않은 자살과 이를 둘러싼 가짜 뉴스\n\n쏟아지는 가짜 속에서 단 하나의 진실을 찾기 위한 취재가 시작된다','심은경, 마츠자카 토리, 타나카 테츠지, 타카하시 카즈야','후지이 미치히토','2019.10.17','2020-09-04','12세 이상 관람가','113분',0,'드라마','2019-11-12 07:50:47',NULL),(15,'토막살인범의 고백','전 결코 그녀가 상처받기를 원하지 않았습니다.\n우리는 사랑하는 사이였어요….\n\n천재적인 재능으로 교수님의 총애를 듬뿍 받고 있는 프로그램 개발자 피트.\n연구에만 몰두하며 외톨이로 지내지만 언제나 밝고 환한 클라라에게 마음을 빼앗기게 된다.\n\n그러던 어느 날, 클라라와 함께 논문 과제를 하게 된 피트는\n그녀와 가까워졌단 생각에 고백을 하게 되지만 클라라는 거절하고,\n두 사람의 사이는 어색해진다.\n\n실연의 상처로 방황하던 피트에게 미안한 클라라는 그를 위로해주기 위해 집으로 찾아간다.\n그러나 클라라가 피트의 집으로 갔던 그날 이후,\n그녀의 모습은 그 어디에서도 찾을 수가 없게 되는데…','아담 일드 로웨더, 파올리나 갈라즈카, 아만다 틀러머, 피트 부코스키','리누스 드 파올리','2019.10.17','2020-09-04','청소년관람불가','86분',0,'드라마','2019-11-12 07:50:47',NULL),(16,'꼬마 자전거 타요','따르릉 따르릉 비켜나세요~!\n레이서 영웅을 꿈꾸는 꼬마 자전거의 위대한 모험!\n\n마을에서 가장 빠른 꼬마 자전거 ‘스피디 타요’는\n언젠가 세계 최고의 레이서가 되겠다는 꿈을 가지고 있다.\n레이싱 대회 1등으로 마을의 슈퍼스타가 된 ‘록’을 만난 ‘스피디 타요’.\n‘록’은 더 빠른 속도와 마을의 발전을 위해 자전거에\n모두 휘발유 모터를 달아야 한다고 주장한다.\n하지만 ‘스피디 타요’는 마을을 오염시키는 휘발유 모터의 비밀을 알게 되고,\n이를 막기 위한 레이싱 대결을 펼치기 시작하는데…\n검은 연기로 가득 찰 위기에 처한 자전거 마을!\n과연 ‘스피디 타요’와 친구들은 마을을 지켜낼 수 있을까?','','마누엘 J. 가르시아','2019.10.17','2020-09-04','전체 관람가','76분',0,'애니메이션','2019-11-12 07:50:47',NULL),(17,'두번할까요','그 날의 ‘이혼식’ 이후 제대로 꼬이기 시작했다?!\n \n꿈꿔왔던 싱글라이프 ‘현우’\n쪽팔림을 무릅쓰고 감행했던 이혼식 후, 드디어 싱글라이프 입성!\n꿈꿔왔던 자유를 되찾은 것도 잠시... 엑스와이프 \'선영\'이 다시 돌아왔다.\n게다가 옛 친구 \'상철\'까지 달고!\n \n원치않던 싱글라이프 ‘선영’\n꼭 해야만(?)했던 이혼식 후, 어쩌다 보니 싱글라이프 입성!\n원수 같던 \'현우\'와 헤어지긴 했지만 그 없이는 어려운 일 투성이다.\n그러던 어느 날, 모든 게 완벽한 \'상철\'이 나타났다!\n \n끝내고픈 싱글라이프 ‘상철’\n이상형 \'선영\'과의 강렬한(!) 만남 후, 잘만하면 싱글라이프 청산 가능!\n얼굴, 능력 다 되지만 연애는 어떻게 하는 건지 도통 모르겠다.\n별 수 없이 연애 상담을 위해 \'현우\'를 찾아가는데!\n \n다시 얽혀버린 세 남녀의 출구 없는 싱글라이프가 펼쳐진다!','권상우, 이정현, 이종혁, 성동일, 정상훈','박용집','2019.10.17','2020-09-04','15세 이상 관람가','112분',0,'코미디','2019-11-12 07:50:47',NULL),(18,'82년생김지영','1982년 봄에 태어나\n누군가의 딸이자 아내, 동료이자 엄마로\n2019년 오늘을 살아가는 ‘지영’(정유미).\n때론 어딘가 갇힌 듯 답답하기도 하지만\n남편 ‘대현’(공유)과 사랑스러운 딸,\n그리고 자주 만나지 못해도 항상 든든한 가족들이 ‘지영’에겐 큰 힘이다.\n \n하지만 언젠가부터 마치 다른 사람이 된 것처럼 말하는 ‘지영’.\n‘대현’은 아내가 상처 입을까 두려워 그 사실을 털어놓지 못하고\n‘지영’은 이런 ‘대현’에게 언제나 “괜찮다”라며 웃어 보이기만 하는데…\n \n모두가 알지만 아무도 몰랐던\n당신과 나의 이야기\n\n','정유미, 공유, 김미경','김도영','2019.10.23','2020-09-04','12세 이상 관람가','118분',0,'드라마','2019-11-12 07:50:47',NULL),(19,'말리피센트2','강력한 어둠의 요정이자 무어스 숲의 수호자 ‘말레피센트’가\n딸처럼 돌봐온 ‘오로라’와 필립 왕자의 결혼 약속으로\n인간 왕국의 ‘잉그리스 왕비’와 대립하게 되고\n이에 요정과 인간의 연합이 깨지면서 벌어지는 거대한 전쟁을 그린 판타지 블록버스터\n','안젤리나 졸리, 엘르 패닝, 미셸 파이퍼','요아킴 뢰닝','2019.10.17','2020-09-04','12세 이상 관람가','119분',0,'드라마','2019-11-12 07:50:47',NULL),(20,'터미네이터: 다크 페이트','심판의 날 그 후, 모든 것이 다시 시작된다!\n\n심판의 날 그 후, 뒤바뀐 미래\n새로운 인류의 희망 ‘대니’(나탈리아 레이즈)를 지키기 위해 슈퍼 솔져 ‘그레이스’(맥켄지 데이비스)가\n미래에서 찾아오고, ‘대니’를 제거하기 위한 터미네이터 ‘Rev-9’(가브리엘 루나)의 추격이 시작된다.\n\n최첨단 기술력으로 무장한 최강의 적 터미네이터 ‘Rev-9’의 무차별적인 공격에 쫓기기 시작하던\n‘그레이스’와 ‘대니’ 앞에 터미네이터 헌터 ‘사라 코너’(린다 해밀턴)가 나타나 도움을 준다.\n\n인류의 수호자이자 기계로 강화된 슈퍼 솔져 ‘그레이스’와 ‘사라 코너’는 ‘대니’를 지키기 위해\n새로운 조력자를 찾아 나서고, 터미네이터 ‘Rev-9’은 그들의 뒤를 끈질기게 추격하는데...\n\n더 이상 정해진 미래는 없다\n지키려는 자 VS 제거하려는 자, 새로운 운명이 격돌한다!\n','맥켄지 데이비스, 아놀드 슈왈제네거, 린다 해밀턴, 나탈리아 레이즈','팀 밀러','2019.10.30','2020-09-04','15세이상관람가','128분',5,'액션, 모험, SF','2019-11-12 08:07:58',NULL);
/*!40000 ALTER TABLE `tbl_movie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_reservation`
--

DROP TABLE IF EXISTS `tbl_reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_reservation` (
  `reservation_num` varchar(150) NOT NULL,
  `movie_num` int(50) NOT NULL,
  `id` varchar(50) NOT NULL,
  `screening_num` int(10) NOT NULL,
  `seat_location` varchar(10) NOT NULL,
  `reservation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reservation_num`),
  KEY `movie_num` (`movie_num`),
  KEY `id` (`id`),
  KEY `screening_num` (`screening_num`),
  CONSTRAINT `tbl_reservation_ibfk_1` FOREIGN KEY (`movie_num`) REFERENCES `tbl_movie` (`movie_num`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_reservation_ibfk_2` FOREIGN KEY (`id`) REFERENCES `tbl_member` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_reservation_ibfk_3` FOREIGN KEY (`screening_num`) REFERENCES `tbl_screening` (`screening_num`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_reservation`
--

LOCK TABLES `tbl_reservation` WRITE;
/*!40000 ALTER TABLE `tbl_reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_screening`
--

DROP TABLE IF EXISTS `tbl_screening`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_screening` (
  `screening_num` int(10) NOT NULL AUTO_INCREMENT,
  `cinema_num` int(10) NOT NULL,
  `movie_num` int(50) NOT NULL,
  `movie_start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `movie_end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reserved_seat_num` int(10) DEFAULT '0',
  `is_screening` int(1) NOT NULL,
  PRIMARY KEY (`screening_num`),
  KEY `movie_num` (`movie_num`),
  KEY `cinema_num` (`cinema_num`),
  CONSTRAINT `tbl_screening_ibfk_1` FOREIGN KEY (`movie_num`) REFERENCES `tbl_movie` (`movie_num`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_screening_ibfk_2` FOREIGN KEY (`cinema_num`) REFERENCES `tbl_cinema` (`cinema_num`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_screening`
--

LOCK TABLES `tbl_screening` WRITE;
/*!40000 ALTER TABLE `tbl_screening` DISABLE KEYS */;
INSERT INTO `tbl_screening` VALUES (1,1,2,'2019-12-01 01:00:00','2019-12-01 03:00:00',0,1),(2,1,2,'2019-12-01 04:25:00','2019-12-01 06:25:00',0,1),(3,1,2,'2019-12-01 06:00:00','2019-12-01 00:30:00',0,1),(4,1,2,'2019-12-01 08:00:00','2019-12-01 10:00:00',0,1),(5,1,2,'2019-12-02 01:00:00','2019-12-02 03:00:00',0,1),(6,1,2,'2019-12-02 04:25:00','2019-12-02 06:25:00',0,1),(7,1,2,'2019-12-02 06:00:00','2019-12-02 00:30:00',0,1),(8,1,2,'2019-12-02 08:00:00','2019-12-02 10:00:00',0,1),(9,1,2,'2019-12-03 01:00:00','2019-12-02 03:00:00',0,1),(10,1,2,'2019-12-03 04:25:00','2019-12-03 06:25:00',0,1);
/*!40000 ALTER TABLE `tbl_screening` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_seat`
--

DROP TABLE IF EXISTS `tbl_seat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_seat` (
  `cinema_num` int(10) NOT NULL,
  `seat_num` varchar(20) NOT NULL,
  PRIMARY KEY (`cinema_num`,`seat_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_seat`
--

LOCK TABLES `tbl_seat` WRITE;
/*!40000 ALTER TABLE `tbl_seat` DISABLE KEYS */;
INSERT INTO `tbl_seat` VALUES (1,'a01'),(1,'a02'),(1,'a03'),(1,'a04'),(1,'a05'),(1,'a06'),(1,'a07'),(1,'a08'),(1,'a09'),(1,'a10'),(1,'b01'),(1,'b02'),(1,'b03'),(1,'b04'),(1,'b05'),(1,'b06'),(1,'b07'),(1,'b08'),(1,'b09'),(1,'b10'),(1,'c01'),(1,'c02'),(1,'c03'),(1,'c04'),(1,'c05'),(1,'c06'),(1,'c07'),(1,'c08'),(1,'c09'),(1,'c10'),(1,'d01'),(1,'d02'),(1,'d03'),(1,'d04'),(1,'d05'),(1,'d06'),(1,'d07'),(1,'d08'),(1,'d09'),(1,'d10'),(1,'e02'),(1,'e03'),(1,'e04'),(1,'e05'),(1,'e06'),(1,'e07'),(1,'e08'),(1,'e09'),(1,'f03'),(1,'f04'),(1,'f05'),(1,'f06'),(1,'f07'),(1,'f08'),(2,'a01'),(2,'a02'),(2,'a03'),(2,'a04'),(2,'a05'),(2,'a06'),(2,'a07'),(2,'a08'),(2,'a09'),(2,'b01'),(2,'b02'),(2,'b03'),(2,'b04'),(2,'b05'),(2,'b06'),(2,'b07'),(2,'b08'),(2,'b09'),(2,'c01'),(2,'c02'),(2,'c03'),(2,'c04'),(2,'c05'),(2,'c06'),(2,'c07'),(2,'c08'),(2,'c09'),(2,'d01'),(2,'d02'),(2,'d03'),(2,'d04'),(2,'d05'),(2,'d06'),(2,'d07'),(2,'d08'),(2,'d09'),(2,'e02'),(2,'e03'),(2,'e04'),(2,'e05'),(2,'e06'),(2,'e07'),(2,'e08'),(2,'e09'),(3,'a01'),(3,'a02'),(3,'a03'),(3,'a04'),(3,'a05'),(3,'a06'),(3,'a07'),(3,'a08'),(3,'b01'),(3,'b02'),(3,'b03'),(3,'b04'),(3,'b05'),(3,'b06'),(3,'b07'),(3,'b08'),(3,'c01'),(3,'c02'),(3,'c03'),(3,'c04'),(3,'c05'),(3,'c06'),(3,'c07'),(3,'c08'),(3,'d03'),(3,'d04'),(3,'d05'),(3,'d06'),(4,'a01'),(4,'a02'),(4,'a03'),(4,'a04'),(4,'a05'),(4,'a06'),(4,'a07'),(4,'b01'),(4,'b02'),(4,'b03'),(4,'b04'),(4,'b05'),(4,'b06'),(4,'b07'),(4,'c01'),(4,'c02'),(4,'c03'),(4,'c04'),(4,'c05'),(4,'c06'),(4,'c07'),(4,'d03'),(4,'d04'),(4,'d05'),(4,'d06'),(4,'d07');
/*!40000 ALTER TABLE `tbl_seat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_view`
--

DROP TABLE IF EXISTS `tbl_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_view` (
  `movie_num` int(50) NOT NULL,
  `view_path` varchar(100) NOT NULL,
  PRIMARY KEY (`movie_num`,`view_path`),
  CONSTRAINT `tbl_view_ibfk_1` FOREIGN KEY (`movie_num`) REFERENCES `tbl_movie` (`movie_num`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_view`
--

LOCK TABLES `tbl_view` WRITE;
/*!40000 ALTER TABLE `tbl_view` DISABLE KEYS */;
INSERT INTO `tbl_view` VALUES (1,'this_poster.jpg'),(2,'tazza_poster.jpg'),(3,'jangsali_poster.jpg'),(4,'yangja_mullihag_poster.jpg'),(5,'joker_poster.jpg'),(6,'Hollywood_poster.jpg'),(7,'botong_poster.jpg'),(8,'jeminimaen_poster.jpg'),(9,'perfectman_poster.jpg'),(10,'destiny_poster.jpg'),(11,'lost_world_poster.jpg'),(12,'sopianddragon_poster.jpg'),(13,'the_summer_i_met_you_poster.jpg'),(14,'newspaper_poster.jpg'),(15,'tomagsalin_poster.jpg'),(16,'tayo_poster.jpg'),(17,'crazy_poster.jpg'),(18,'82kim.jpg'),(19,'maleficent.jpg'),(20,'terminator.jpg');
/*!40000 ALTER TABLE `tbl_view` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-12 17:12:22
